﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    internal class AboutBox
    {
        public AboutBox1()
        {
            InitializeComponent();

            this.Text = String.Format("О {0}", AssemblyTitle);
            this.labelProductName.Text = AssemblyProduct;
            this.labelVersion.Text = String.Format("Версия {0}", AssemblyVersion);
            this.labelCopyright.Text = "Zолкина Виктория"; // AssemblyCopyright;
            this.labelCompanyName.Text = AssemblyCompany;
            this.textBoxDescription.Text = "Очень интересное приложение Прям супер-пупер Всем рекомендую!!!!"; //AssemblyDescription;
        }
    }
}
